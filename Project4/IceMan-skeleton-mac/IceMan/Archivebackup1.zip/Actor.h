#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"

// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp

#include "StudentWorld.h"
#include <stack>

enum State {stable=1, waiting=2, falling=3, dead=0, active=4, pickablebyiceman=5, pickablebyprotesters=6, bribed=7};
struct Node
{
    Node(int X, int Y):x(X),y(Y){}
    Node(){}
    int x;
    int y;
};
class Actor: public GraphObject
{

public:
   
    Actor(int imageID, int startX, int startY, Direction dir, double size, unsigned int depth);
    Actor(StudentWorld* s,int imageID, int startX, int startY, Direction dir, double size, unsigned int depth);
    virtual ~Actor(){}
    virtual void doSomething(){return;}
    virtual StudentWorld* getWorld()
    {
        return p;
    }
    int gethealth() const {return m_hitpoints;}
    void sethealth(int h){ m_hitpoints=h;}
    State getState(){return s;}
    void setState(State state){s=state;}
    virtual void decreaseHealth(int v){m_hitpoints-=v;}
    void move(Direction);
    void moveinthecurrentdirection();
    bool checkblock(Direction,int,int ); // by ice or by boulder or by boundary
    virtual void resetRestingtickcounts(int){}
    void moveonestep(int,int);
private:
    State s;
    StudentWorld *p;
    int m_hitpoints;

};


class Ice: public Actor
{
public:
    Ice(int startX, int startY): Actor(IID_ICE, startX, startY, right, 0.25, 3){}
    virtual ~Ice(){}
};


class Iceman: public Actor
{
public:
    Iceman(StudentWorld *pointer);
    virtual ~Iceman(){}
    virtual void doSomething();
    int getSquirts() const { return m_water;}
    int getGold() const {return m_nuggets;}
    int getSonar() const {return m_sonar;}
    void increaseGold(){m_nuggets++;}
    void increaseSonar(){m_sonar++;}
    void increaseSquirts(){m_water+=5;}
    void decreaseHealth (int v);
private:
    int m_sonar;
    int m_water;
    int m_nuggets;
    virtual bool checkblock(Direction);//check boulder and boundary
    void cleanice();
};

class Boulders: public Actor
{
public:
    Boulders(StudentWorld *pointer,int startX, int startY);
    virtual ~Boulders(){}
    virtual void doSomething();
private:
    int countdown;
};

class Squirt: public Actor
{
public:
    Squirt(StudentWorld *pointer, int x, int y, Direction d);
    virtual ~Squirt(){}
    virtual void doSomething();
private:
    int countdown;
};

class Barrel: public Actor
{
public:
    Barrel(StudentWorld *p, int,int);
    virtual ~Barrel(){}
    virtual void doSomething();
    
};

class GoldNugget: public Actor
{
public:
    GoldNugget(StudentWorld *p,int,int, State, bool);
    virtual ~GoldNugget(){}
    virtual void doSomething();
private:
    int countdown;
};

class Goodies: public Actor
{
public:
    Goodies(StudentWorld *p, int, int, int imageID);
    virtual ~Goodies(){}
    virtual void doSomething();
private:
    int countdown;
};

class SonarKit: public Goodies
{
public:
    SonarKit(StudentWorld *p, int, int);
    virtual ~SonarKit(){}
};

class WaterPool: public Goodies
{
public:
    WaterPool(StudentWorld *p, int, int);
    virtual ~WaterPool(){}
};

class Protester: public Actor
{
public:
    Protester(StudentWorld *p, int imageID);
    virtual ~Protester(){}
    virtual void doSomething();
    virtual void decreaseHealth(int);
    virtual void resetRestingtickcounts(int);
    void findshortestpath(int,int, std::stack<Node*> &);
private:
    int restingTickCounts;
    int numSquaresToMoveInCurrentDirection;
    int ticksToWaitBetweenMoves;
    int shout;// to record the non-resting tick count without shouting
    int perpendicularturn; // to  to record the non-resting tick count without perpendicularturn
    void shoutaticeman();
    bool visited[64][64]; //"visited" table
    Node* prev[64][64]; //"previous" table
    Node nodes[64][64]; // Nodes table
    std::stack<Node*> S; //Stack to hold the exit route
    std::stack<Node*> S2;//Stack to hold hard core protester chasing route
};

class RegProtester:public Protester
{
public:
    RegProtester(StudentWorld *p);
    virtual ~RegProtester(){}
};

class HardcoreProtester: public Protester
{
public:
    HardcoreProtester(StudentWorld *p);
    virtual ~HardcoreProtester(){}

};







#endif // ACTOR_H_
